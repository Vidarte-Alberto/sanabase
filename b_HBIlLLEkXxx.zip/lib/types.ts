export interface Patient {
  id: string
  nombreCompleto: string
  edad: number
  sexo: "Masculino" | "Femenino" | "Otro"
  fechaNacimiento: string
  telefono: string
  direccion: string
  correoElectronico: string
  tipoSangre: "A+" | "A-" | "B+" | "B-" | "AB+" | "AB-" | "O+" | "O-"
  alergias: string
  antecedentesMedicos: string
  motivoConsulta: string
  observaciones: string
  fechaRegistro: string
  ultimaActualizacion: string
}

export type PatientFormData = Omit<Patient, "id" | "fechaRegistro" | "ultimaActualizacion">

export const BLOOD_TYPES = ["A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"] as const

export const SEX_OPTIONS = ["Masculino", "Femenino", "Otro"] as const
