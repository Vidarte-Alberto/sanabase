import type { Patient, PatientFormData } from "./types"

// Datos de ejemplo para demostración
const initialPatients: Patient[] = [
  {
    id: "1",
    nombreCompleto: "María García López",
    edad: 35,
    sexo: "Femenino",
    fechaNacimiento: "1991-03-15",
    telefono: "555-123-4567",
    direccion: "Calle Principal 123, Col. Centro",
    correoElectronico: "maria.garcia@email.com",
    tipoSangre: "O+",
    alergias: "Penicilina",
    antecedentesMedicos: "Hipertensión controlada",
    motivoConsulta: "Revisión general",
    observaciones: "Paciente estable, continuar con medicación actual",
    fechaRegistro: "2024-01-15",
    ultimaActualizacion: "2024-03-10",
  },
  {
    id: "2",
    nombreCompleto: "Juan Pérez Martínez",
    edad: 45,
    sexo: "Masculino",
    fechaNacimiento: "1981-07-22",
    telefono: "555-987-6543",
    direccion: "Av. Reforma 456, Col. Juárez",
    correoElectronico: "juan.perez@email.com",
    tipoSangre: "A+",
    alergias: "Ninguna conocida",
    antecedentesMedicos: "Diabetes tipo 2",
    motivoConsulta: "Control de glucosa",
    observaciones: "Niveles de glucosa mejorados, mantener dieta",
    fechaRegistro: "2024-02-01",
    ultimaActualizacion: "2024-03-05",
  },
  {
    id: "3",
    nombreCompleto: "Ana Rodríguez Sánchez",
    edad: 28,
    sexo: "Femenino",
    fechaNacimiento: "1998-11-08",
    telefono: "555-456-7890",
    direccion: "Blvd. Insurgentes 789, Col. Roma",
    correoElectronico: "ana.rodriguez@email.com",
    tipoSangre: "B+",
    alergias: "Sulfas, Mariscos",
    antecedentesMedicos: "Asma leve",
    motivoConsulta: "Síntomas respiratorios",
    observaciones: "Prescribir broncodilatador",
    fechaRegistro: "2024-02-20",
    ultimaActualizacion: "2024-03-01",
  },
]

class PatientStore {
  private patients: Patient[] = [...initialPatients]
  private listeners: Set<() => void> = new Set()
  private snapshot: Patient[] = this.patients

  subscribe(listener: () => void) {
    this.listeners.add(listener)
    return () => this.listeners.delete(listener)
  }

  private notify() {
    this.snapshot = [...this.patients]
    this.listeners.forEach((listener) => listener())
  }

  getPatients(): Patient[] {
    return this.snapshot
  }

  getPatient(id: string): Patient | undefined {
    return this.patients.find((p) => p.id === id)
  }

  addPatient(data: PatientFormData): Patient {
    const now = new Date().toISOString().split("T")[0]
    const newPatient: Patient = {
      ...data,
      id: crypto.randomUUID(),
      fechaRegistro: now,
      ultimaActualizacion: now,
    }
    this.patients = [newPatient, ...this.patients]
    this.notify()
    return newPatient
  }

  updatePatient(id: string, data: Partial<PatientFormData>): Patient | undefined {
    const index = this.patients.findIndex((p) => p.id === id)
    if (index === -1) return undefined

    const now = new Date().toISOString().split("T")[0]
    this.patients[index] = {
      ...this.patients[index],
      ...data,
      ultimaActualizacion: now,
    }
    this.patients = [...this.patients]
    this.notify()
    return this.patients[index]
  }

  deletePatient(id: string): boolean {
    const index = this.patients.findIndex((p) => p.id === id)
    if (index === -1) return false

    this.patients = this.patients.filter((p) => p.id !== id)
    this.notify()
    return true
  }

  searchPatients(query: string): Patient[] {
    const lowerQuery = query.toLowerCase()
    return this.patients.filter(
      (p) =>
        p.nombreCompleto.toLowerCase().includes(lowerQuery) ||
        p.correoElectronico.toLowerCase().includes(lowerQuery) ||
        p.telefono.includes(query)
    )
  }
}

export const patientStore = new PatientStore()
