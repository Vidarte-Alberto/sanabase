"use client"

import { useSyncExternalStore, useCallback } from "react"
import { patientStore } from "@/lib/patient-store"
import type { Patient, PatientFormData } from "@/lib/types"

const subscribe = (callback: () => void) => patientStore.subscribe(callback)
const getSnapshot = () => patientStore.getPatients()
const getServerSnapshot = () => patientStore.getPatients()

export function usePatients() {
  const patients = useSyncExternalStore(
    subscribe,
    getSnapshot,
    getServerSnapshot
  )

  const addPatient = useCallback((data: PatientFormData) => {
    return patientStore.addPatient(data)
  }, [])

  const updatePatient = useCallback((id: string, data: Partial<PatientFormData>) => {
    return patientStore.updatePatient(id, data)
  }, [])

  const deletePatient = useCallback((id: string) => {
    return patientStore.deletePatient(id)
  }, [])

  const getPatient = useCallback((id: string): Patient | undefined => {
    return patientStore.getPatient(id)
  }, [])

  const searchPatients = useCallback((query: string) => {
    return patientStore.searchPatients(query)
  }, [])

  return {
    patients,
    addPatient,
    updatePatient,
    deletePatient,
    getPatient,
    searchPatients,
  }
}
