"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Spinner } from "@/components/ui/spinner"
import { X, Save, UserPlus } from "lucide-react"
import type { Patient, PatientFormData } from "@/lib/types"
import { BLOOD_TYPES, SEX_OPTIONS } from "@/lib/types"

interface PatientFormProps {
  patient?: Patient
  onSubmit: (data: PatientFormData) => void
  onCancel: () => void
  isLoading?: boolean
}

const initialFormData: PatientFormData = {
  nombreCompleto: "",
  edad: 0,
  sexo: "Masculino",
  fechaNacimiento: "",
  telefono: "",
  direccion: "",
  correoElectronico: "",
  tipoSangre: "O+",
  alergias: "",
  antecedentesMedicos: "",
  motivoConsulta: "",
  observaciones: "",
}

export function PatientForm({ patient, onSubmit, onCancel, isLoading }: PatientFormProps) {
  const [formData, setFormData] = useState<PatientFormData>(initialFormData)
  const isEditing = !!patient

  useEffect(() => {
    if (patient) {
      setFormData({
        nombreCompleto: patient.nombreCompleto,
        edad: patient.edad,
        sexo: patient.sexo,
        fechaNacimiento: patient.fechaNacimiento,
        telefono: patient.telefono,
        direccion: patient.direccion,
        correoElectronico: patient.correoElectronico,
        tipoSangre: patient.tipoSangre,
        alergias: patient.alergias,
        antecedentesMedicos: patient.antecedentesMedicos,
        motivoConsulta: patient.motivoConsulta,
        observaciones: patient.observaciones,
      })
    }
  }, [patient])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    onSubmit(formData)
  }

  const updateField = <K extends keyof PatientFormData>(field: K, value: PatientFormData[K]) => {
    setFormData((prev) => ({ ...prev, [field]: value }))
  }

  return (
    <Card className="w-full border-border/50 shadow-lg">
      <CardHeader className="border-b border-border/50 bg-muted/30">
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2 text-xl">
              {isEditing ? (
                <>
                  <Save className="h-5 w-5 text-primary" />
                  Editar Paciente
                </>
              ) : (
                <>
                  <UserPlus className="h-5 w-5 text-primary" />
                  Nuevo Paciente
                </>
              )}
            </CardTitle>
            <CardDescription className="mt-1">
              {isEditing
                ? "Actualiza la información del paciente"
                : "Ingresa los datos del nuevo paciente"}
            </CardDescription>
          </div>
          <Button variant="ghost" size="icon" onClick={onCancel}>
            <X className="h-5 w-5" />
          </Button>
        </div>
      </CardHeader>
      <CardContent className="p-6">
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Información Personal */}
          <div className="space-y-4">
            <h3 className="text-sm font-medium text-muted-foreground uppercase tracking-wide">
              Información Personal
            </h3>
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="sm:col-span-2">
                <Label htmlFor="nombreCompleto">Nombre Completo *</Label>
                <Input
                  id="nombreCompleto"
                  value={formData.nombreCompleto}
                  onChange={(e) => updateField("nombreCompleto", e.target.value)}
                  placeholder="Nombre completo del paciente"
                  required
                  className="mt-1.5"
                />
              </div>
              <div>
                <Label htmlFor="fechaNacimiento">Fecha de Nacimiento *</Label>
                <Input
                  id="fechaNacimiento"
                  type="date"
                  value={formData.fechaNacimiento}
                  onChange={(e) => {
                    updateField("fechaNacimiento", e.target.value)
                    // Calculate age
                    const birthDate = new Date(e.target.value)
                    const today = new Date()
                    let age = today.getFullYear() - birthDate.getFullYear()
                    const monthDiff = today.getMonth() - birthDate.getMonth()
                    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
                      age--
                    }
                    updateField("edad", age > 0 ? age : 0)
                  }}
                  required
                  className="mt-1.5"
                />
              </div>
              <div>
                <Label htmlFor="edad">Edad</Label>
                <Input
                  id="edad"
                  type="number"
                  value={formData.edad}
                  onChange={(e) => updateField("edad", parseInt(e.target.value) || 0)}
                  min={0}
                  max={150}
                  className="mt-1.5"
                />
              </div>
              <div>
                <Label htmlFor="sexo">Sexo *</Label>
                <Select
                  value={formData.sexo}
                  onValueChange={(value) => updateField("sexo", value as PatientFormData["sexo"])}
                >
                  <SelectTrigger className="mt-1.5">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {SEX_OPTIONS.map((option) => (
                      <SelectItem key={option} value={option}>
                        {option}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="tipoSangre">Tipo de Sangre *</Label>
                <Select
                  value={formData.tipoSangre}
                  onValueChange={(value) =>
                    updateField("tipoSangre", value as PatientFormData["tipoSangre"])
                  }
                >
                  <SelectTrigger className="mt-1.5">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {BLOOD_TYPES.map((type) => (
                      <SelectItem key={type} value={type}>
                        {type}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>

          {/* Información de Contacto */}
          <div className="space-y-4">
            <h3 className="text-sm font-medium text-muted-foreground uppercase tracking-wide">
              Información de Contacto
            </h3>
            <div className="grid gap-4 sm:grid-cols-2">
              <div>
                <Label htmlFor="telefono">Teléfono *</Label>
                <Input
                  id="telefono"
                  type="tel"
                  value={formData.telefono}
                  onChange={(e) => updateField("telefono", e.target.value)}
                  placeholder="555-123-4567"
                  required
                  className="mt-1.5"
                />
              </div>
              <div>
                <Label htmlFor="correoElectronico">Correo Electrónico</Label>
                <Input
                  id="correoElectronico"
                  type="email"
                  value={formData.correoElectronico}
                  onChange={(e) => updateField("correoElectronico", e.target.value)}
                  placeholder="paciente@email.com"
                  className="mt-1.5"
                />
              </div>
              <div className="sm:col-span-2">
                <Label htmlFor="direccion">Dirección</Label>
                <Input
                  id="direccion"
                  value={formData.direccion}
                  onChange={(e) => updateField("direccion", e.target.value)}
                  placeholder="Calle, número, colonia, ciudad"
                  className="mt-1.5"
                />
              </div>
            </div>
          </div>

          {/* Información Médica */}
          <div className="space-y-4">
            <h3 className="text-sm font-medium text-muted-foreground uppercase tracking-wide">
              Información Médica
            </h3>
            <div className="grid gap-4">
              <div>
                <Label htmlFor="alergias">Alergias</Label>
                <Textarea
                  id="alergias"
                  value={formData.alergias}
                  onChange={(e) => updateField("alergias", e.target.value)}
                  placeholder="Lista de alergias conocidas..."
                  rows={2}
                  className="mt-1.5"
                />
              </div>
              <div>
                <Label htmlFor="antecedentesMedicos">Antecedentes Médicos</Label>
                <Textarea
                  id="antecedentesMedicos"
                  value={formData.antecedentesMedicos}
                  onChange={(e) => updateField("antecedentesMedicos", e.target.value)}
                  placeholder="Historial médico relevante..."
                  rows={3}
                  className="mt-1.5"
                />
              </div>
              <div>
                <Label htmlFor="motivoConsulta">Motivo de Consulta</Label>
                <Textarea
                  id="motivoConsulta"
                  value={formData.motivoConsulta}
                  onChange={(e) => updateField("motivoConsulta", e.target.value)}
                  placeholder="Razón de la visita..."
                  rows={2}
                  className="mt-1.5"
                />
              </div>
              <div>
                <Label htmlFor="observaciones">Observaciones Generales</Label>
                <Textarea
                  id="observaciones"
                  value={formData.observaciones}
                  onChange={(e) => updateField("observaciones", e.target.value)}
                  placeholder="Notas adicionales..."
                  rows={3}
                  className="mt-1.5"
                />
              </div>
            </div>
          </div>

          {/* Actions */}
          <div className="flex flex-col-reverse sm:flex-row gap-3 pt-4 border-t border-border/50">
            <Button type="button" variant="outline" onClick={onCancel} className="flex-1 sm:flex-none">
              Cancelar
            </Button>
            <Button type="submit" disabled={isLoading} className="flex-1 sm:flex-none">
              {isLoading && <Spinner className="mr-2 h-4 w-4" />}
              {isEditing ? "Guardar Cambios" : "Registrar Paciente"}
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  )
}
