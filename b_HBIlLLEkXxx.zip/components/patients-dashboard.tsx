"use client"

import { useState, useMemo } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Empty } from "@/components/ui/empty"
import { PatientCard } from "@/components/patient-card"
import { PatientForm } from "@/components/patient-form"
import { PatientDetail } from "@/components/patient-detail"
import { DeleteConfirmDialog } from "@/components/delete-confirm-dialog"
import { SearchBar } from "@/components/search-bar"
import { StatsCards } from "@/components/stats-cards"
import { usePatients } from "@/hooks/use-patients"
import { toast } from "sonner"
import { UserPlus, Users, LayoutGrid, List } from "lucide-react"
import type { Patient, PatientFormData } from "@/lib/types"

type ViewMode = "list" | "detail" | "form"

export function PatientsDashboard() {
  const { patients, addPatient, updatePatient, deletePatient } = usePatients()
  const [viewMode, setViewMode] = useState<ViewMode>("list")
  const [selectedPatient, setSelectedPatient] = useState<Patient | null>(null)
  const [patientToDelete, setPatientToDelete] = useState<Patient | null>(null)
  const [searchQuery, setSearchQuery] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [listStyle, setListStyle] = useState<"grid" | "list">("grid")

  const filteredPatients = useMemo(() => {
    if (!searchQuery.trim()) return patients
    const query = searchQuery.toLowerCase()
    return patients.filter(
      (p) =>
        p.nombreCompleto.toLowerCase().includes(query) ||
        p.correoElectronico.toLowerCase().includes(query) ||
        p.telefono.includes(searchQuery)
    )
  }, [patients, searchQuery])

  const handleAddNew = () => {
    setSelectedPatient(null)
    setViewMode("form")
  }

  const handleView = (patient: Patient) => {
    setSelectedPatient(patient)
    setViewMode("detail")
  }

  const handleEdit = (patient: Patient) => {
    setSelectedPatient(patient)
    setViewMode("form")
  }

  const handleDelete = (patient: Patient) => {
    setPatientToDelete(patient)
  }

  const handleConfirmDelete = () => {
    if (patientToDelete) {
      deletePatient(patientToDelete.id)
      toast.success("Paciente eliminado", {
        description: `${patientToDelete.nombreCompleto} ha sido eliminado del sistema.`,
      })
      setPatientToDelete(null)
      if (selectedPatient?.id === patientToDelete.id) {
        setViewMode("list")
        setSelectedPatient(null)
      }
    }
  }

  const handleFormSubmit = async (data: PatientFormData) => {
    setIsLoading(true)
    
    // Simulate API delay
    await new Promise((resolve) => setTimeout(resolve, 500))

    if (selectedPatient) {
      updatePatient(selectedPatient.id, data)
      toast.success("Paciente actualizado", {
        description: `Los datos de ${data.nombreCompleto} han sido actualizados.`,
      })
    } else {
      addPatient(data)
      toast.success("Paciente registrado", {
        description: `${data.nombreCompleto} ha sido agregado al sistema.`,
      })
    }

    setIsLoading(false)
    setViewMode("list")
    setSelectedPatient(null)
  }

  const handleCancel = () => {
    setViewMode("list")
    setSelectedPatient(null)
  }

  if (viewMode === "form") {
    return (
      <div className="mx-auto max-w-3xl">
        <PatientForm
          patient={selectedPatient || undefined}
          onSubmit={handleFormSubmit}
          onCancel={handleCancel}
          isLoading={isLoading}
        />
      </div>
    )
  }

  if (viewMode === "detail" && selectedPatient) {
    return (
      <div className="mx-auto max-w-3xl">
        <PatientDetail
          patient={selectedPatient}
          onClose={handleCancel}
          onEdit={handleEdit}
          onDelete={handleDelete}
        />
        <DeleteConfirmDialog
          patient={patientToDelete}
          open={!!patientToDelete}
          onOpenChange={(open) => !open && setPatientToDelete(null)}
          onConfirm={handleConfirmDelete}
        />
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Stats */}
      <StatsCards patients={patients} />

      {/* Patient List */}
      <Card className="border-border/50">
        <CardHeader className="border-b border-border/50">
          <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
            <CardTitle className="flex items-center gap-2">
              <Users className="h-5 w-5 text-primary" />
              Lista de Pacientes
            </CardTitle>
            <div className="flex items-center gap-2">
              <div className="hidden sm:flex items-center border border-border rounded-lg">
                <Button
                  variant={listStyle === "grid" ? "secondary" : "ghost"}
                  size="sm"
                  className="rounded-r-none"
                  onClick={() => setListStyle("grid")}
                >
                  <LayoutGrid className="h-4 w-4" />
                </Button>
                <Button
                  variant={listStyle === "list" ? "secondary" : "ghost"}
                  size="sm"
                  className="rounded-l-none"
                  onClick={() => setListStyle("list")}
                >
                  <List className="h-4 w-4" />
                </Button>
              </div>
              <Button onClick={handleAddNew}>
                <UserPlus className="mr-2 h-4 w-4" />
                Nuevo Paciente
              </Button>
            </div>
          </div>
          <div className="pt-4">
            <SearchBar
              value={searchQuery}
              onChange={setSearchQuery}
              placeholder="Buscar por nombre, correo o teléfono..."
            />
          </div>
        </CardHeader>
        <CardContent className="p-4 md:p-6">
          {filteredPatients.length === 0 ? (
            <Empty className="py-12">
              {searchQuery ? (
                <>
                  <Empty.Title>No se encontraron pacientes</Empty.Title>
                  <Empty.Description>
                    No hay pacientes que coincidan con &quot;{searchQuery}&quot;
                  </Empty.Description>
                  <Empty.Actions>
                    <Button variant="outline" onClick={() => setSearchQuery("")}>
                      Limpiar búsqueda
                    </Button>
                  </Empty.Actions>
                </>
              ) : (
                <>
                  <Empty.Title>Sin pacientes registrados</Empty.Title>
                  <Empty.Description>
                    Comienza agregando tu primer paciente al sistema.
                  </Empty.Description>
                  <Empty.Actions>
                    <Button onClick={handleAddNew}>
                      <UserPlus className="mr-2 h-4 w-4" />
                      Agregar Paciente
                    </Button>
                  </Empty.Actions>
                </>
              )}
            </Empty>
          ) : (
            <>
              <div className="mb-4 text-sm text-muted-foreground">
                {filteredPatients.length}{" "}
                {filteredPatients.length === 1 ? "paciente encontrado" : "pacientes encontrados"}
              </div>
              <div
                className={
                  listStyle === "grid"
                    ? "grid gap-4 sm:grid-cols-2 lg:grid-cols-3"
                    : "space-y-3"
                }
              >
                {filteredPatients.map((patient) => (
                  <PatientCard
                    key={patient.id}
                    patient={patient}
                    onView={handleView}
                    onEdit={handleEdit}
                    onDelete={handleDelete}
                  />
                ))}
              </div>
            </>
          )}
        </CardContent>
      </Card>

      <DeleteConfirmDialog
        patient={patientToDelete}
        open={!!patientToDelete}
        onOpenChange={(open) => !open && setPatientToDelete(null)}
        onConfirm={handleConfirmDelete}
      />
    </div>
  )
}
